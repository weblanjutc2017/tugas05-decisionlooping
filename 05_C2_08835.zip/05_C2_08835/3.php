<?php
$tujuh = 0;
for ($i=1; $i<=100; $i++) {
	if ($i%7 == 0){
		echo "$i &nbsp";
	}
}
?>