<? php

for($a=0; $a<100; $a=$a+7){
	echo $a;
	echo "<br/>";
}

?>