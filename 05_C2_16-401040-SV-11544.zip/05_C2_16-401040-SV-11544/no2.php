<?php
	$x=0;
	for($y = 1; $y<= 100; $y++){
		if($y%2 != 0){
			$x += 1;
		}
	}
	echo $x;
?>