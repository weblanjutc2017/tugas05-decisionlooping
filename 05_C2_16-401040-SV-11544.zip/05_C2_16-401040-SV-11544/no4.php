<?php

$status = "Single";
$income = 30000;


if($status=="Single"){
	if($income>=0 && $income <32000){
		$a = $income*0.1;
		echo $a;
	}
	elseif($income>=32000){
		$b = $income*0.25+3200;
		echo $b;
	}
}
else{
	if($income>=0 && $income <64000){
		$c = $income*0.1;
		echo $c;
	}
	elseif($income>=64000){
		$d = $income*0.25+6400;
		echo $d;
	}
}
?>