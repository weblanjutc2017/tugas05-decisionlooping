<?php

$nilai='A-';
echo "Nilai : $nilai</br>";
echo "Keterangan : ";
 switch ($nilai) {
 	case 'A' || 'A-'||'A/B'||'B+'||'B'||'B-'||'B/C':
 		echo "LULUS </br>";
 		break;
 	case 'C+' || 'C-'||'C/D'||'C':
 		echo "LULUS SEBAIKNYA DIULANG </br>";
 		break;
 	case 'D' || 'D+':
 		echo "LULUS & WAJIB DIULANG </br>";
 		break;
 	default:
 		echo "TIDAK LULUS</br>";
 		break;
 }
?>