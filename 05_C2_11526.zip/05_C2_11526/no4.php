<?php 
$status = 'Single';
$t=80000;

if ($status=='Single') {
	if ($t>0 && $t<=32000) {
		echo "Besarnya : ". 0.1*$t . "</br>";
	} else {
		$h2=0.25*$t+3200;
		echo "Besarnya : $h2 </br>";
	}
	
} elseif($status=='Married'){
	if ($t>0 && $t<=64000) {
		echo "Besarnya : ". 0.1*$t . "</br>";
	} else {
		$h3=0.25*$t+6400;
		echo "Besarnya : $h3 </br>";
	}
}

?>