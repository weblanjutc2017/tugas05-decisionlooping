<?php
$bil=1;
$jum=0;
while ( $bil<= 100) {
	$jum=$jum+$bil;
	$bil=$bil+2;
}
echo "Jumlahnya : $jum";

?>