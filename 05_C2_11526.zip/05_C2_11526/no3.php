<?php
$bil=7;
while ( $bil<= 100) {
	echo "$bil </br>";
	$bil=$bil+7;
}

//cara lain
echo "</br>Dengan Cara Lain : </br>";
$bil=1;
while ( $bil<= 100) {
	if ($bil%7==0) {
		echo "$bil </br>";
	}
	$bil++;
}

?>