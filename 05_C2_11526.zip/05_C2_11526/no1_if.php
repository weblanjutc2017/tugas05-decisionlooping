<?php
$nilai='D';
echo "Nilai : $nilai</br>";
echo "Keterangan : ";
if ($nilai=='A' || $nilai=='A-'||$nilai=='A/B'||$nilai=='B+'||$nilai=='B-'||$nilai=='B/C'||$nilai=='B' ) {
	echo "LULUS</br>";
} elseif ($nilai=='C+' || $nilai=='C-'||$nilai=='C'||$nilai=='C/D') {
	echo "LULUS SEBAIKNYA DIULANG</br>";
} elseif ($nilai=='D+' || $nilai=='D') {
	echo "LULUS & WAJIB DIULANG</br>";
}else {
	echo "TIDAK LULUS</br>";
}
?>