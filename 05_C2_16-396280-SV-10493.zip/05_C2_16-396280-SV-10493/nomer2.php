<?php
	$gan=0;
	for($bil = 1; $bil<= 100; $bil++){
		if($bil%2 != 0){
			$gan += 1;
		}
	}
	echo $gan;
?>