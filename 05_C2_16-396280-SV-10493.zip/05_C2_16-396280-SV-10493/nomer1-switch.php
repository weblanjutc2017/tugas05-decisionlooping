<?php
$nilai = "A";

switch ($nilai) {
    case "A":
	case "A-":
	case "A/B":
	case "B+":
	case "B":
	case "B-":
	case "B/C":
        echo "LULUS";
        break;
    case "C+":
	case "C":
	case "C-":
	case "C/D":
        echo "LULUS SEBAIKNYA DIULANG";
        break;
    case "D+":
	case "D":
        echo "LULUS WAJIB DIULANG";
        break;
	case "E":
		echo "TIDAK LULUS";
		break;
	default:
		echo "NILAI SALAH";
}
?>