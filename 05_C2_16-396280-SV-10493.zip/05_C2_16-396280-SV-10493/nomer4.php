<?php

$status = "Single";
$income = 31500;


if($status=="Single"){
	if($income>=0 && $income <32000){
		echo $income*0.1;
	}
	elseif($income>=32000){ 
		echo $income*0.25+3200;
	}
}
else{
	if($income>=0 && $income <64000){ 
		echo $income*0.1;
	}
	elseif($income>=64000){
		echo $income*0.25+6400;
	}
}
?>