<?php

for($i=0; $i<100; $i=$i+7){
	echo $i;
	echo "<br/>";
}

?>