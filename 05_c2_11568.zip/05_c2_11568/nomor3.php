<?php

for($x=0; $x<100; $x=$x+7){
	echo $x;
	echo "<br/>";
}

?>