<?php
$nilai="E";

switch ($nilai){
	case $nilai== "A" ||$nilai== "A-" ||$nilai== "A/B" ||$nilai== "B+" ||$nilai== "B"||$nilai== "B-" ||$nilai== "B/C" :
		echo "LULUS";
		break;
	case $nilai== "C+" ||$nilai== "C" ||$nilai== "C-" ||$nilai== "C/D":
		echo "LULUS SEBAIKNYA DIULANG";
		break;
	case $nilai =="C/D" ||$nilai== "D+" ||$nilai== "D":
		echo "LULUS DAN WAJIB DIULANG";
		break;
	case $nilai=="E":
		echo "TIDAK LULUS";
		break;
	default:
		echo "NILAI TIDAK VALID";
		break;
}
?>