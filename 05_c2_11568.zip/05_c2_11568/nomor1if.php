<?php
$nilai= "E" ;

if($nilai== "A" ||$nilai== "A-" ||$nilai== "A/B" ||$nilai== "B+" ||$nilai== "B"||$nilai== "B-" ||$nilai== "B/C" ){
	echo "LULUS";
	
} 
else if($nilai== "C+" ||$nilai== "C" ||$nilai== "C-" ||$nilai== "C/D" ){
	echo "LULUS SEBAIKNYA DIULANG";
}
else if($nilai =="C/D" ||$nilai== "D+" ||$nilai== "D" ){
	echo "LULUS DAN WAJIB DIULANG";
}
else if ($nilai=="E"){
	echo "TIDAK LULUS";
}
else { echo "NILAI TIDAK VALID";}
?>