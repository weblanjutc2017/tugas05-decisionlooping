<?php
//income=x 
$status = "Married";
$x = 30000;


if($status=="Single"){
	if($x>=0 && $x <32000){
		$a = $x*0.1;
		echo $a;
	}
	else if($x>=32000){
		$b = $x*0.25+3200;
		echo $b;
	}
}
else{
	if($x>=0 && $x <64000){
		$c = $x*0.1;
		echo $c;
	}
	else if($x>=64000){
		$d = $x*0.25+6400;
		echo $d;
	}
}
?>