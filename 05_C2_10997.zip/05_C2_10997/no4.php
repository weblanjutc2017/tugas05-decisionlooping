<?php
$status = 'married';
$income = 64100;

if($status == 'single'){
	if($income>0 && $income<=32000){
		$income = $income * 0.1;
	}
	else if($income> 32000){
		$income = 3200+ ($income * 0.25);
	}
}

else if($status == 'married'){
	if($income>0 && $income<=64000){
		$income = $income * 0.1;
	}
	else if($income> 64000){
		$income = 6400+ ($income * 0.25);
	}
}

echo $income;
?>