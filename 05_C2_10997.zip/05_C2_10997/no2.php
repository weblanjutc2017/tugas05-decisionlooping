<?php
$x = 1;
$tampil = 0;

for($x=1; $x<=100; $x++){
	if($x % 2 != 0){
		$tampil++;
	}
}
echo "$tampil";
?>