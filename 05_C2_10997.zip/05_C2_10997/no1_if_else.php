<?php
$nilai= 'A';

if($nilai == 'A' || $nilai =='A-' || $nilai =='A/B' || $nilai =='B+' || $nilai =='B' || $nilai =='B-' || $nilai =='B/C'){
	echo "LULUS";
}
else if($nilai == 'C+' || $nilai =='C' || $nilai =='C-' || $nilai =='C/D' || $nilai =='B'){
	echo "LULUS SEBAIKNYA MENGULANG";
}
else if($nilai == 'D+' || $nilai =='D'){
	echo "LULUS & WAJIB MENGULANG";
}
else if($nilai == 'E'){
	echo "TIDAK LULUS";
}
else{
	echo "Maaf nilai yang dimasukkan salah";
}
?>