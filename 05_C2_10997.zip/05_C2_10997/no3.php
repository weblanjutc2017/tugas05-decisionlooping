<?php
$x = 1;

for($x=1; $x<=100; $x++){
	if($x % 7 == 0){
		echo "$x ";
	}
}
?>